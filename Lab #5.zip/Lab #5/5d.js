function Student(firstName, lastName, id, grades) {
  this.firstName = firstName;
  this.lastName = lastName;
  this.id = id;
  this.grades = grades;
  this.printInfo = function() {
    console.log(this.firstName + ' ' + this.lastName + ' ' + this.averageGrade);
  }
}

Object.defineProperties(Student.prototype, {
  fullName: {

    get: function () {
      return this.firstName + ' ' + this.lastName;
    }

  },

  averageGrade: {
    get: function () {
      let sum = 0;
      for (let i = 0; i < this.grades.length; ++i) {
        sum += this.grades[i];
      }
      return sum / this.grades.length;
    }

  }

});

let student = new Student('Janusz', 'Kowalski',16717,[4,2,1,2,2,3,4,3,5,4])
student.printInfo();
console.log('full name: ' + student.fullName);
console.log('average grade: ' + student.averageGrade);