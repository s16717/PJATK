function Student(firstName, lastName, id, grades) {
  this.firstName = firstName;
  this.lastName = lastName;
  this.id = id;
  this.grades = grades;
  function getAverageGrade() {
    let sum = 0;
    for (let i = 0; i < grades.length; ++i) {
      sum += grades[i];
    }
    return sum / grades.length;
  }

  this.printInfo = function() {
    console.log(this.firstName + ' ' + this.lastName + ' ' + getAverageGrade());
  }
}

let student = new Student('Janusz', 'Kowalski',16717,[4,2,1,2,2,3,4,3,5,4])
student.printInfo();