let object = {
  name: 'Janusz',
  surname: 'Kowalski',
  age: 21,
  salary: 4000,
  getName: function () { console.log('Name: ' + this.name); },
  getSalary() { console.log('Salary: ' + this.salary); },
  getAge: function () { console.log('Age: ' + this.age); }
}

function displayObject(obj) {
  Object.keys(obj).forEach(function (key, index) {
    console.log(index + '. ' + 'property name: ' + key + '\n\tproperty type: ' + typeof (obj[key]) + '\n\tproperty value: ' + obj[key]);
  });
}

displayObject(object);
