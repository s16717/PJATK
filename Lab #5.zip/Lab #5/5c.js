let Student = {
  firstName : 'Janusz',
  lastName : 'Kowalski',
  id : 16717,
  courses : ['GameDev', 'Unity', 'JavaScript', 'Computer Graphic']
};

function displayObject(obj) {
  Object.keys(obj).forEach(function (key, index) {
    console.log(index + '. ' + 'propertyName: ' + key + '\n\tpropertyType: ' + typeof (obj[key]) + '\n\tpropertVal: ' + obj[key]);
  });
}

function registerNewStudent(firstName, lastName, id){
  let newStudent = Object.create(Student);
  newStudent.firstName = firstName;
  newStudent.lastName = lastName;
  newStudent.id = id;
  newStudent.courses = Student.courses;
  return newStudent;
}

console.log('Creating new student:')
let newStudent = registerNewStudent('Outer', 'Worlds', 17429);
displayObject(newStudent);
