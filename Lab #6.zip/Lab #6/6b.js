function paragraph() {
  const br = document.createElement('br');
  const paragraph = 'During the Nintendo Spotlight @ E3 2017, The Pokémon Company CEO, Tsunekazu Ishihara confirmed that Game Freak had begun development on the first Pokémon title for the Nintendo Switch device. No details were made about the game other than it being a core Pokémon RPG and details coming in more than a year During a press event in Japan on May 30th 2018, it was then confirmed that the Eighth Generation of Pokémon will release on the Nintendo Switch in 2019 and the games were fully unveiled during a Pokémon Direct on February 27th 2019.';
  const text = document.createTextNode(paragraph);
  document.body.appendChild(text);
  document.body.appendChild(br);
}

window.onload = () => {
  setTimeout(paragraph, 5000);
};
