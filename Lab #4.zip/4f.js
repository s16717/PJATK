function isPrime(num) {
  for (let i = 2; i<num; ++i) {
    if (num % i === 0) { return false;}
  }
  return true;
}


function run(arg) {
  console.log(arg +" is" +(isPrime(arg)? " a prime number.":" not a prime number."));
}


let a = 7;
let b = 22;
run(a);
run(b);