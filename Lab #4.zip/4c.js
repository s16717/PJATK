function isPalindrome(str) {
  let len = str.length;
  for (let i = 0; i < len / 2; ++i) {
    if (str.charAt(i) !== str.charAt(len - 1 - i)) {
      return false;
    }
  }
  return true;
}

let notPalindrome = "JavaScript",
  palindrome = "kajak";
console.log(
  "Is " + notPalindrome + " a palindrome? : " + isPalindrome(notPalindrome)
);
console.log(
  "Is " + palindrome + " a palindrome? : " + isPalindrome(palindrome)
);