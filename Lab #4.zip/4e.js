function longestWord(str){
  let strArr = str.split(" ").sort((a,b) => b.length - a.length);
  return strArr[0];
}

let test = "JavaScript, often abbreviated as JS, is a high-level, interpreted scripting language that conforms to the ECMAScript specification. JavaScript has curly-bracket syntax, dynamic typing, prototype-based object-orientation, and first-class functions.";
console.log('The longest word in "',test,'" is ',longestWord(test));