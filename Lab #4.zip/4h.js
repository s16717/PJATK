function secondHighest(arr){
  let sorted = arr.sort((a,b) => a-b);
  let res = sorted[arr.length-2];
  return res;
}
function secondLowest(arr){
  let sorted = arr.sort((a,b) => a-b);
  let res = sorted[1];
  return res;
}

let arr = [62, 70, 33,	8, 10, 89, 92, 94, 23, 69];
let high = secondHighest(arr);
let low = secondLowest(arr);
console.log('lowest: ' + low, " highest: " + high);