function binarySearch(sortedArr, key){
  let l = 0, r = sortedArr.length -1;
  
  while (l <= r) {
    let m = Math.round((l + r)/2);
    if (sortedArr[m] === key) return m;
    else {
      if(sortedArr[m] > key) r = m -1;
      else l = m + 1;
    }
  }
  return -1;
}

let arr = [11, 15, 23, 48, 52, 70, 85, 86, 92, 100];
let key = 70;
console.log(arr);
console.log(key + " is at index " + binarySearch(arr, key));