function getType(arg) {
  return typeof(arg);
}

let a = 5;
console.log('a has type',getType(a));

let b = "5";
console.log('b has type',getType(b));