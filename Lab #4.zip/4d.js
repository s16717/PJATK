function sortLetters(str) {
  let strArr = str.split("");
  return strArr.sort().join("");
}


let x = 'webmaster';
console.log(x, " -> ", sortLetters(x));